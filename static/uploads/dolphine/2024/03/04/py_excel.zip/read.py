import pandas as pd

df = pd.read_excel('MOCK_DATA.xlsx')

for index,row, in df.itemrrows():
    print(row)